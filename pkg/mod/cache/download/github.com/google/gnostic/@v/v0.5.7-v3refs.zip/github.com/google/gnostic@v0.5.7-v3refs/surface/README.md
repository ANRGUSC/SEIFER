# API Code Surface

This directory contains a Protocol Buffer-language model suitable for
generating support code for calling and implementing an API.

It can be generated from other formats read by gnostic and passed to code
generator plugins to assist them by providing a preprocessed API description
that is easier to generate.
