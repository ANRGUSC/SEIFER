package main

import "github.com/BGrewell/go-iperf"

func main() {
	iperf.ExtractBinaries()
}
