package iperf

type Protocol string

const (
	PROTO_TCP = "tcp"
	PROTO_UDP = "udp"
)
