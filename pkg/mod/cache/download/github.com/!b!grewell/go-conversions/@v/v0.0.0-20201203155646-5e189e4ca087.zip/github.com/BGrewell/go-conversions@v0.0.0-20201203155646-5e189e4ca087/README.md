# go-conversions
Go-Conversions is a helper library to help with common conversions such as from network rates to int values
