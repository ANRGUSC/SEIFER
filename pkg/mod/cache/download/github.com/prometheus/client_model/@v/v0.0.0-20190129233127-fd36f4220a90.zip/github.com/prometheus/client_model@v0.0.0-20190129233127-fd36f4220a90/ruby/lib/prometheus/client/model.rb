require 'prometheus/client/model/metrics.pb'
require 'prometheus/client/model/version'
